#include<bits/stdc++.h>
using namespace std;
bool cmp(pair<int,int>score1,pair<int,int>score2)
{
    return(score1.first<score2.first);
}
int main()
{
    int t,n,p,s,i,m;
    cin>>t;
    while(t--){
    cin>>n;
    pair<int,int>score[n];
    int sum=0;
    for(i=0;i<n;i++)
    {
        cin>>p>>s;
        score[i].first=p;
        score[i].second=s;
    }

    sort(score,score+n,cmp);
    for(i=0;i<n;i++)
    {
        if(score[i].first==score[i+1].first&&score[i].second<score[i+1].second)
            swap(score[i].second,score[i+1].second);
    }

        for(int s=1;s<=8;s++)
        {
            for(i=0;i<n;i++){
            if(score[i].first==s){
                sum=sum+score[i].second;
            break;}
            }
        }
                cout<<sum<<endl;

    }
    return 0;
}
