#include<bits/stdc++.h>
using namespace std;
#define MAX 40000
int a[MAX];
int main()
{
    long long int n;
    int t,i,j;

    ios::sync_with_stdio(0);
    cin>>t;
    while(t--){
        int c=0;
        cin>>n;
    for(i=1;i<=n;i++)cin>>a[i];

    for(i=1;i<=n;i++){
        for(j=i+1;j<=n;j++)
        {
            if((a[i]+a[j])==(a[i]*a[j])) c++;
        }
    }
    cout<<c<<endl;
    }
    return 0;
}
