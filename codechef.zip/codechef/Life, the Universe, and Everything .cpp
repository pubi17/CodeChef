try:
    my_list = []

    while True:
        my_list.append(int(input()))

except:
    for a in my_list:
        if a == 42: break;
        else : print(a)
