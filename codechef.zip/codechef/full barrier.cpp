#include<bits/stdc++.h>
using namespace std;

int main() {
	int T,n,h,y1,y2,l,t[1000],x[1000];
	cin>>T;
	while(T--)
	{
		cin>>n>>h>>y1>>y2>>l;
		int c=0,f=0;
		for(int j=0;j<n;j++)
		{
			cin>>t[j]>>x[j];
			if(f==0)
			{
				if(t[j]==1)
		    	{
		    		int H=h-y1;
			    	if(H<=x[j])
		    		c++;
			    	else
		    		{
		    			if(l>1)
		    			{
		    				c++;
		    				l--;
						}
						else if(l>0)
						{
							f=1;



							l--;
						}
		    		}
    			}
	    		else
			    {
				    int H=y2;
				    if(H>=x[j])
				    c++;
				    //else if(y2>=x[j])
				    //c++;
				    else
				    {
				    	if(l>1)
				    	{
				    		c++;
				    		l--;
						}
						else if(l>0)
						{
							f=1;
							l--;
						}
				    }
			    }
			}
		}
		cout<<c<<endl;
	}
	return 0;
}
