#include<bits/stdc++.h>
using namespace std;
int convert(int n)
{
    int d=0,i=0,r;
    while(n!=0)
    {
        r=n%10;
        n/=10;
        d+=r*pow(2,i);
        ++i;
    }
    return d;
}

int main()
{
    int a,b,u,v,c=0,t,B,A;

    cin>>a>>b;

    u=convert(a);
    v=convert(b);
    B=v;
    while(B>0)
    {
        A=u;
        B=v*2;
        c++;
    }
    cout<<c<<endl;

    return 0;
}
