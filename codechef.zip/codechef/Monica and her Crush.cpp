#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
    {
        string s; cin >> s; int sz = s.size();

        int n; cin >> n;
        int cnt = 0, i=0;
        for(int k=0; k<n; ++k)
        {
            string a; cin >> a;

            for(auto x:a){
                if(s[i]==x){cnt++; i++; break;}
            }
        }

        if(n==sz){
            if(cnt==sz) cout<<"YES"<<endl;
            else cout<<"NO"<<endl;
        }
        else cout<<"NO"<<endl;
    }

    return 0;
}
