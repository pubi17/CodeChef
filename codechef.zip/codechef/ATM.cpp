#include<bits/stdc++.h>
#include<iomanip>
using namespace std;

int main()
{
    int x;
    double y;
    ios::sync_with_stdio(0);
    cin>>x>>y;
    if(x%5==0)
    {
        if(x<y)
        {
            cout<<fixed<<setprecision(2)<<y-x-(0.5)<<endl;
        }
        else
        {
            cout<<fixed<<setprecision(2)<<y<<endl;
        }
    }
    else
    {
        cout<<fixed<<setprecision(2)<<y<<endl;
    }
    return 0;
}
