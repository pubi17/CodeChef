#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int t; cin >> t;
    while(t--)
    {
        string s; cin >> s;
        int n = s.size();
        int i=0;
        bool res = true;
        while(i<n/2)
        {
            if(s[i] == s[n-i-1])i++;
            else {res = false; break;}
        }
        cout << ((res) ? "YES" : "NO") << endl;
    }

    return 0;
}
