#include<bits/stdc++.h>
using namespace std;

template<class T> int former(const vector<T> &v, T x) { return upper_bound(v.begin(), v.end(), x) - v.begin() - 1; }
template<class T> int latter(const vector<T> &v, T x) { return lower_bound(v.begin(), v.end(), x) - v.begin(); }
template<class T> inline bool chmax(T& a, T b) { if (a < b) { a = b; return 1; } return 0; }
template<class T> inline bool chmin(T& a, T b) { if (a > b) { a = b; return 1; } return 0; }

#define sum(a)     ( accumulate ((a).begin(), (a).end(), 0ll))
#define mine(a)    (*min_element((a).begin(), (a).end()))
#define maxe(a)    (*max_element((a).begin(), (a).end()))
#define mini(a)    ( min_element((a).begin(), (a).end()) - (a).begin())
#define maxi(a)    ( max_element((a).begin(), (a).end()) - (a).begin())
#define lowb(a, x) ( lower_bound((a).begin(), (a).end(), (x)) - (a).begin())
#define uppb(a, x) ( upper_bound((a).begin(), (a).end(), (x)) - (a).begin())
int power(int x, int y){int temp;if( y == 0)return 1; temp = power(x, y / 2);if (y % 2 == 0) return temp * temp;else return x * temp * temp;}
int log2n( int n){ return (n > 1) ? 1 + log2n(n / 2) : 0;}
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef tuple<int,int,int> T;
#define gcd(a,b) __gcd((a),(b))
#define lcmll(a,b) a*((b)/gcd((a),(b)))
#define lcm(a,b) ((a)*(b))/gcd((a),(b))

ll inf=1e18+42;
const double eps = 1e-8;
#define M_PI 3.14159265358979323846
const int M = 1e9+7;
const int MN = 1e9;

int main()
{
    ///freopen("input.txt", "r", stdin);
   ///freopen("output.txt", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(10);
    int t; cin >> t;
    while(t--)
    {
        int a, b, c; cin >> a >> b >> c;
        int mn = min({a, b, c});

        if(mn == a) cout <<"Draw"<< endl;
        else if(mn == b) cout << "Bob" << endl;
        else if(mn == c) cout << "Alice" << endl;
    }

    return 0;
}
