#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;

    cin>>t;
    while(t--)
    {
        int i,j,k,ln=0,c=0;
    string s;
        cin>>s;
        ln=s.size();

        for(i=0;i<=ln-1;i++)
        {
            for(j=i;j<=ln-1;j++)
            {
                if(i==j){
                    if(s[i]=='0') s[i]='1';
                    else s[i]='0';
                }
                else{
                    if(s[i]=='0') s[i]='1';
                    else if(s[i]=='1') s[i]='0';
                    if(s[j]=='0') s[j]='1';
                    else if(s[j]=='1') s[j]='0';
                }



       for(k=0;k<=ln-1;k++)
        {
            if(s[k]==s[k+1]) c++;
        }
}

        }

       cout<<c<<endl;
    }
    return 0;
}
